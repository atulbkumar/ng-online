/*
(function(){
	angular.module("app").config(function($routeProvider){
		$routeProvider.when("/",{
			controller : "heroesContorller"
		})
	});
}());
*/